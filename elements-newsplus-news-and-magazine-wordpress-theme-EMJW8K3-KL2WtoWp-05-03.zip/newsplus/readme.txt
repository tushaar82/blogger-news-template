Kindly refer to the "documentation/index.html" file inside your theme download package for installation and usage instructions.

Thanks,
Saurabh Sharma
